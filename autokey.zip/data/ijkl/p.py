# Enter script code
keyboard.send_key("p")