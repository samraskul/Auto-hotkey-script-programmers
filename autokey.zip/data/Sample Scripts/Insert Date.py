output = system.exec_command("date")
keyboard.send_keys(output)